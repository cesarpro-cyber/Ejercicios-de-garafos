package Grafos;

import java.util.*;

public class GrafoMatriz {
    private int[][] matriz;
    private String[] nodos;

    public GrafoMatriz(String[] nodos) {
        this.nodos = nodos;
        matriz = new int[nodos.length][nodos.length];
    }

    public void agregarArista(int i, int j) {
        matriz[i][j] = 1;
        matriz[j][i] = 1; // grafo no dirigido
    }

    public void bfs(int inicio) {
        boolean[] visitados = new boolean[nodos.length];
        Queue<Integer> cola = new LinkedList<>();
        cola.add(inicio);
        visitados[inicio] = true;

        System.out.print("BFS (Matriz): ");
        while (!cola.isEmpty()) {
            int nodo = cola.poll();
            System.out.print(nodos[nodo] + " ");
            for (int j = 0; j < nodos.length; j++) {
                if (matriz[nodo][j] == 1 && !visitados[j]) {
                    visitados[j] = true;
                    cola.add(j);
                }
            }
        }
        System.out.println();
    }

    public void dfs(int inicio) {
        boolean[] visitados = new boolean[nodos.length];
        System.out.print("DFS (Matriz): ");
        dfsRec(inicio, visitados);
        System.out.println();
    }

    private void dfsRec(int nodo, boolean[] visitados) {
        visitados[nodo] = true;
        System.out.print(nodos[nodo] + " ");
        for (int j = 0; j < nodos.length; j++) {
            if (matriz[nodo][j] == 1 && !visitados[j]) {
                dfsRec(j, visitados);
            }
        }
    }
}
