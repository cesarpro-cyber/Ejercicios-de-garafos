package Grafos;

import java.util.*;

public class GrafoLista {
    private Map<String, List<String>> adj;

    public GrafoLista() {
        adj = new HashMap<>();
    }

    public void agregarArista(String origen, String destino) {
        adj.putIfAbsent(origen, new LinkedList<>());
        adj.putIfAbsent(destino, new LinkedList<>());
        adj.get(origen).add(destino);
        adj.get(destino).add(origen); // grafo no dirigido
    }

    public void bfs(String inicio) {
        Set<String> visitados = new HashSet<>();
        Queue<String> cola = new LinkedList<>();
        cola.add(inicio);
        visitados.add(inicio);

        System.out.print("BFS (Lista): ");
        while (!cola.isEmpty()) {
            String nodo = cola.poll();
            System.out.print(nodo + " ");
            for (String vecino : adj.get(nodo)) {
                if (!visitados.contains(vecino)) {
                    visitados.add(vecino);
                    cola.add(vecino);
                }
            }
        }
        System.out.println();
    }

    public void dfs(String inicio) {
        Set<String> visitados = new HashSet<>();
        System.out.print("DFS (Lista): ");
        dfsRec(inicio, visitados);
        System.out.println();
    }

    private void dfsRec(String nodo, Set<String> visitados) {
        visitados.add(nodo);
        System.out.print(nodo + " ");
        for (String vecino : adj.get(nodo)) {
            if (!visitados.contains(vecino)) {
                dfsRec(vecino, visitados);
            }
        }
    }
}
