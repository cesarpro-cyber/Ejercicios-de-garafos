package Grafos;

public class Main {
    public static void main(String[] args) {
        //Lista
        GrafoLista gLista = new GrafoLista();
        gLista.agregarArista("A", "B");
        gLista.agregarArista("A", "C");
        gLista.agregarArista("B", "D");
        gLista.agregarArista("C", "E");
        gLista.agregarArista("D", "F");
        gLista.agregarArista("E", "F");

        gLista.bfs("A");
        gLista.dfs("A");

        //Matriz
        String[] nodos = {"A", "B", "C", "D", "E", "F", "G"};
        GrafoMatriz gMatriz = new GrafoMatriz(nodos);

        gMatriz.agregarArista(0, 1); // A-B
        gMatriz.agregarArista(0, 2); // A-C
        gMatriz.agregarArista(1, 3); // B-D
        gMatriz.agregarArista(2, 4); // C-E
        gMatriz.agregarArista(3, 5); // D-F
        gMatriz.agregarArista(4, 6); // E-G

        gMatriz.bfs(0);
        gMatriz.dfs(0);
    }
}
